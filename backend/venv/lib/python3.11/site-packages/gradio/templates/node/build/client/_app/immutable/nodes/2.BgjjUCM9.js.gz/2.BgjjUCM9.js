import { N, _ } from "../chunks/2.BuStSfbP.js";
export {
  N as component,
  _ as universal
};
